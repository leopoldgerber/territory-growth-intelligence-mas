import { HomePage } from './pages/HomePage';

import './styles.css';

export function App() {
  return <HomePage />;
}
