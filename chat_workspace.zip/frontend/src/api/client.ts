export type HealthStatus = {
  status: string;
  backend: string;
  database: string;
  app_name: string;
  environment: string;
};

export type UploadFileResult = {
  file_id: number | null;
  file_name: string;
  report_type: string;
  status: string;
  row_count: number;
  errors: string[];
  warnings: string[];
};

export type QualitySummary = {
  total_checks: number;
  passed: number;
  warnings: number;
  failed: number;
};

export type QualityCheck = {
  check_id: number;
  file_name: string | null;
  table_name: string | null;
  check_name: string;
  check_type: string | null;
  status: string | null;
  severity: string | null;
  message: string | null;
  affected_rows_count: number | null;
  quality_dimension: string | null;
};

export type QualityResult = {
  run_id: number;
  quality_status: string;
  summary: QualitySummary;
  checks: QualityCheck[];
};

export type QualityRunSummary = {
  run_id: number;
  started_at: string | null;
  status: string | null;
  quality_status: string | null;
  total_checks: number;
  failed: number;
  warnings: number;
};

export type UploadRunResult = {
  run_id: number;
  status: string;
  quality_status: string;
  quality_summary: QualitySummary | null;
  row_count: number;
  files: UploadFileResult[];
  errors: string[];
  warnings: string[];
};

export type UploadRunSummary = {
  run_id: number;
  source_name: string | null;
  run_type: string | null;
  granularity: string | null;
  status: string | null;
  quality_status: string | null;
  row_count: number;
  started_at: string | null;
  finished_at: string | null;
  error_message: string | null;
};

export type UploadRunDetail = UploadRunSummary & {
  files: UploadFileResult[];
};

export type UploadOptions = {
  sourceName: string;
  isSynthetic: boolean;
  granularity: string;
  periodStart: string;
  periodEnd: string;
};

export type CountryItem = {
  country_id: number;
  country_name_en: string;
  country_name_ru: string | null;
  region_name_en: string | null;
  region_name_ru: string | null;
  has_data: boolean;
};

export type CountryList = {
  items: CountryItem[];
  total: number;
};

export type CountryPeriod = {
  country_id: number;
  date_min: string | null;
  date_max: string | null;
  available_days: number;
};

export type CountrySummaryMetrics = {
  total_competitor_traffic: number;
  active_competitors_count: number;
  leader_domain: string | null;
  leader_company: string | null;
  leader_traffic: number | null;
  leader_share: number | null;
  top_3_share: number | null;
  desktop_traffic: number | null;
  mobile_traffic: number | null;
  desktop_share: number | null;
  mobile_share: number | null;
  traffic_no_bounce: number | null;
  traffic_bounce: number | null;
  no_bounce_share: number | null;
  bounce_share: number | null;
  avg_bounce_rate: number | null;
  avg_pages_per_visit: number | null;
  avg_visit_duration_seconds: number | null;
};

export type TopCompetitorItem = {
  rank: number;
  domain_id: number;
  domain: string;
  company_id: number | null;
  company_name: string | null;
  traffic: number;
  traffic_share: number | null;
  desktop_traffic: number | null;
  mobile_traffic: number | null;
  desktop_share: number | null;
  mobile_share: number | null;
  bounce_rate: number | null;
  traffic_no_bounce: number | null;
  traffic_bounce: number | null;
  no_bounce_share: number | null;
};

export type DailyTrendItem = {
  date: string;
  traffic: number;
  desktop_traffic: number | null;
  mobile_traffic: number | null;
  traffic_no_bounce: number | null;
  traffic_bounce: number | null;
};

export type CountrySummary = {
  country: CountryItem;
  period: {
    date_from: string;
    date_to: string;
    days_count: number;
  };
  summary: CountrySummaryMetrics;
  top_competitors: TopCompetitorItem[];
  daily_trend: DailyTrendItem[];
  generated_summary: string;
  quality_warning: string | null;
};

export type MetricLeader = {
  domain_id: number | null;
  domain: string | null;
  company_id: number | null;
  company_name: string | null;
  traffic: number | null;
  share: number | null;
};

export type CountryMetricValues = {
  total_competitor_traffic: number | null;
  active_competitors_count: number | null;
  leader: MetricLeader | null;
  leader_share: number | null;
  top_3_share: number | null;
  market_concentration_hhi: number | null;
  desktop_share: number | null;
  mobile_share: number | null;
  bounce_share: number | null;
  no_bounce_share: number | null;
  avg_bounce_rate: number | null;
  avg_pages_per_visit: number | null;
  avg_visit_duration_seconds: number | null;
  engagement_score: number | null;
  market_volatility_score: number | null;
};

export type CountryMetricsResponse = {
  country: CountryItem;
  period: {
    date_from: string;
    date_to: string;
    days_count: number;
  };
  metrics: CountryMetricValues;
  calculation: {
    calculation_version: string;
    calculated_at: string | null;
    data_quality_status: string | null;
  };
  warning: string | null;
};

export type DailyMetricItem = {
  date: string;
  total_competitor_traffic: number | null;
  active_competitors_count: number | null;
  leader_share: number | null;
  top_3_share: number | null;
  market_concentration_hhi: number | null;
  engagement_score: number | null;
  market_volatility_score: number | null;
};

export type DailyMetricsResponse = {
  country_id: number;
  items: DailyMetricItem[];
};

export type CountryReportRequest = {
  country_id: number;
  date_from: string;
  date_to: string;
  limit_competitors: number;
  include_channels: boolean;
  include_recommendations: boolean;
  calculation_version: string;
};

export type ReportResponse = {
  report_id: number;
  report_type: string;
  status: string;
  title: string;
  country: CountryItem | null;
  period: {
    date_from: string;
    date_to: string;
    days_count: number;
  } | null;
  data_quality_status: string | null;
  report_markdown: string | null;
  report_json: Record<string, unknown> | null;
  created_at: string | null;
};

export type ReportListItem = {
  report_id: number;
  report_type: string;
  title: string;
  report_status: string | null;
  country_name_en: string | null;
  period_start: string;
  period_end: string;
  data_quality_status: string | null;
  created_at: string | null;
};

export type ReportList = {
  items: ReportListItem[];
  total: number;
};

export type CompetitorItem = {
  domain_id: number;
  domain: string;
  company_id: number | null;
  company_name: string | null;
  has_data: boolean;
};

export type CompetitorList = {
  items: CompetitorItem[];
  total: number;
};

export type CompetitorPeriod = {
  domain_id: number;
  domain: string;
  date_min: string | null;
  date_max: string | null;
  available_days: number;
};

export type CompetitorSummaryMetrics = {
  total_traffic: number;
  active_countries_count: number;
  top_country: string | null;
  top_country_traffic: number | null;
  top_country_share: number | null;
  desktop_traffic: number | null;
  mobile_traffic: number | null;
  desktop_share: number | null;
  mobile_share: number | null;
  traffic_no_bounce: number | null;
  traffic_bounce: number | null;
  no_bounce_share: number | null;
  bounce_share: number | null;
  avg_bounce_rate: number | null;
  avg_pages_per_visit: number | null;
  avg_visit_duration_seconds: number | null;
};

export type CompetitorCountryItem = {
  rank: number;
  country_id: number;
  country_name_en: string;
  country_name_ru: string | null;
  region_name_en: string | null;
  traffic: number;
  traffic_share_in_domain: number | null;
  growth_rate: number | null;
  presence_stability_score: number | null;
  desktop_share: number | null;
  mobile_share: number | null;
  bounce_rate: number | null;
  no_bounce_share: number | null;
  country_role: string;
  quality_label: string;
  signal: string | null;
};

export type CompetitorSignalSet = {
  anchor_countries: CompetitorCountryItem[];
  peripheral_countries: CompetitorCountryItem[];
  growing_countries: CompetitorCountryItem[];
  declining_countries: CompetitorCountryItem[];
  new_market_signals: CompetitorCountryItem[];
  abandoned_market_signals: CompetitorCountryItem[];
};

export type CompetitorDailyTrend = {
  date: string;
  traffic: number;
  desktop_traffic: number | null;
  mobile_traffic: number | null;
  traffic_no_bounce: number | null;
  traffic_bounce: number | null;
};

export type CompetitorSummary = {
  competitor: CompetitorItem;
  period: {
    date_from: string;
    date_to: string;
    days_count: number;
  };
  summary: CompetitorSummaryMetrics;
  top_countries: CompetitorCountryItem[];
  signals: CompetitorSignalSet;
  daily_trend: CompetitorDailyTrend[];
  generated_summary: string;
  quality_warning: string | null;
};

export type ChannelScope = {
  scope_type: string;
  country_id: number | null;
  country_name_en: string | null;
  domain_id: number | null;
  domain: string | null;
  company_id: number | null;
  company_name: string | null;
  is_estimated: boolean;
};

export type DominantChannel = {
  channel_id: number | null;
  channel_code: string | null;
  channel_name: string | null;
  traffic: number | null;
  traffic_share: number | null;
};

export type ChannelMetric = {
  channel_id: number;
  channel_code: string;
  channel_name: string;
  traffic: number;
  traffic_share: number | null;
  growth_rate: number | null;
  stability_score: number | null;
  is_dominant_channel: boolean;
  dependency_score: number | null;
  role: string;
  interpretation: string;
};

export type ChannelSummaryMetrics = {
  total_channel_traffic: number;
  dominant_channel: DominantChannel | null;
  channel_dependency_score: number | null;
  channel_diversification_score: number | null;
  channel_profile: string;
};

export type ChannelSummary = {
  scope: ChannelScope;
  period: {
    date_from: string;
    date_to: string;
    days_count: number;
  };
  summary: ChannelSummaryMetrics;
  channels: ChannelMetric[];
  warnings: string[];
  recommendation_hints: string[];
};

export type ChannelTrendItem = {
  date: string;
  channel_id: number;
  channel_code: string;
  channel_name: string;
  traffic: number;
  traffic_share: number | null;
};

export type ChannelTrendResponse = {
  items: ChannelTrendItem[];
};

export type JourneySourceItem = {
  journey_source_id: number;
  source_name: string | null;
  source_type: string | null;
  traffic_type: string | null;
  channel_id: number | null;
  channel_code: string | null;
  channel_name: string | null;
  traffic: number;
  traffic_share: number | null;
  growth_rate: number | null;
  stability_score: number | null;
};

export type JourneySourcesResponse = {
  items: JourneySourceItem[];
  warnings: string[];
};

export type OpportunityScoreValues = {
  opportunity_score: number;
  recommended_priority: string;
  market_type: string;
};

export type OpportunityComponents = {
  traffic_score: number | null;
  competition_score: number | null;
  quality_score: number | null;
  channel_gap_score: number | null;
  volatility_score: number | null;
  localization_potential_score: number | null;
  entry_difficulty_score: number | null;
};

export type OpportunityScore = {
  country: CountryItem;
  period: {
    date_from: string;
    date_to: string;
    days_count: number;
  };
  score: OpportunityScoreValues;
  components: OpportunityComponents;
  strengths: string[];
  risks: string[];
  explanation: string;
  data_quality_status: string;
  calculation: {
    calculation_version: string;
    calculated_at: string | null;
  };
};

export type OpportunityCountryItem = {
  country_id: number;
  country_name_en: string;
  country_name_ru: string | null;
  region_name_en: string | null;
  period_start: string;
  period_end: string;
  opportunity_score: number;
  recommended_priority: string;
  market_type: string;
  traffic_score: number | null;
  competition_score: number | null;
  quality_score: number | null;
  channel_gap_score: number | null;
  entry_difficulty_score: number | null;
};

export type OpportunityCountryList = {
  items: OpportunityCountryItem[];
  total: number;
};

export type BudgetAssumptions = {
  traffic_capture_rate: number;
  visit_to_lead_rate: number;
  lead_to_client_rate: number;
};

export type BudgetStrategyRequest = {
  country_id: number;
  date_from: string;
  date_to: string;
  budget_amount: number;
  currency_code: string;
  campaign_goal: string;
  risk_appetite: string;
  assumptions: BudgetAssumptions | null;
  calculation_version: string;
};

export type BudgetAllocationItem = {
  channel_id: number | null;
  channel_code: string;
  channel_name: string | null;
  budget_share: number;
  budget_amount: number;
  priority: string;
  risk_level: string;
  rationale: string;
  expected_traffic: number;
  expected_leads: number;
  expected_clients: number;
  test_hypothesis: string;
  success_metric: string;
};

export type BudgetStrategyResponse = {
  strategy_id: number;
  country: CountryItem;
  period: {
    date_from: string;
    date_to: string;
    days_count: number;
  };
  budget: {
    amount: number;
    currency_code: string;
  };
  strategy: {
    recommended_strategy_type: string;
    confidence_score: number;
    summary: string;
  };
  allocation: BudgetAllocationItem[];
  expected_effect: {
    expected_traffic: number;
    expected_leads: number;
    expected_clients: number;
  };
  risks: string[];
  recommendations: string[];
  assumptions: BudgetAssumptions;
  data_quality_status: string | null;
};

export type BudgetStrategyListItem = {
  strategy_id: number;
  country_id: number;
  country_name_en: string;
  period_start: string;
  period_end: string;
  budget_amount: number;
  currency_code: string;
  campaign_goal: string | null;
  strategy_status: string | null;
  recommended_strategy_type: string | null;
  total_expected_traffic: number | null;
  confidence_score: number | null;
  created_at: string | null;
};

export type BudgetStrategyList = {
  items: BudgetStrategyListItem[];
  total: number;
};

export type MASAnalyzeRequest = {
  user_query: string;
  country_id: number | null;
  date_from: string | null;
  date_to: string | null;
  budget_amount: number | null;
  currency_code: string;
  campaign_goal: string;
  risk_appetite: string;
  calculation_version: string;
};

export type MASStepItem = {
  agent_step_id: number;
  step_order: number;
  agent_name: string;
  step_type: string | null;
  step_status: string | null;
  summary: string | null;
};

export type MASEvidenceItem = {
  evidence_id: number;
  evidence_type: string | null;
  source_name: string | null;
  source_ref: string | null;
  metric_name: string | null;
  metric_value: number | null;
};

export type MASInsightItem = {
  insight_id: number;
  agent_name: string | null;
  insight_type: string | null;
  title: string;
  summary: string | null;
  severity: string | null;
  confidence_score: number | null;
};

export type MASRecommendationItem = {
  recommendation_id: number;
  recommendation_type: string | null;
  priority: string | null;
  title: string;
  description: string | null;
  rationale: string | null;
  expected_impact: string | null;
  confidence_score: number | null;
};

export type MASRunResponse = {
  agent_run_id: number;
  user_query: string;
  run_status: string | null;
  run_type: string | null;
  country_id: number | null;
  period_start: string | null;
  period_end: string | null;
  budget_amount: number | null;
  currency_code: string | null;
  campaign_goal: string | null;
  final_answer: string | null;
  confidence_score: number | null;
  steps: MASStepItem[];
  evidence: MASEvidenceItem[];
  insights: MASInsightItem[];
  recommendations: MASRecommendationItem[];
};

export type MASRunListItem = {
  agent_run_id: number;
  user_query: string;
  run_status: string | null;
  run_type: string | null;
  country_id: number | null;
  period_start: string | null;
  period_end: string | null;
  confidence_score: number | null;
  created_at: string | null;
};

export type MASRunList = {
  items: MASRunListItem[];
  total: number;
};

export type HistoryReportItem = {
  report_id: number;
  report_type: string;
  title: string;
  country_id: number | null;
  country_name_en: string | null;
  period_start: string | null;
  period_end: string | null;
  data_quality_status: string | null;
  report_status: string | null;
  created_at: string | null;
};

export type HistoryReportList = {
  items: HistoryReportItem[];
  total: number;
};

export type HistoryAgentRunItem = {
  agent_run_id: number;
  run_type: string | null;
  user_query: string;
  country_id: number | null;
  country_name_en: string | null;
  period_start: string | null;
  period_end: string | null;
  budget_amount: number | null;
  currency_code: string | null;
  run_status: string | null;
  confidence_score: number | null;
  created_at: string | null;
};

export type HistoryAgentRunList = {
  items: HistoryAgentRunItem[];
  total: number;
};

export type HistoryInsightItem = {
  insight_id: number;
  agent_run_id: number;
  insight_type: string | null;
  title: string;
  summary: string | null;
  country_id: number | null;
  country_name_en: string | null;
  severity: string | null;
  confidence_score: number | null;
  created_at: string | null;
};

export type HistoryInsightList = {
  items: HistoryInsightItem[];
  total: number;
};

export type HistoryRecommendationItem = {
  recommendation_id: number;
  agent_run_id: number;
  recommendation_type: string | null;
  priority: string | null;
  title: string;
  description: string | null;
  country_id: number | null;
  country_name_en: string | null;
  expected_impact: string | null;
  confidence_score: number | null;
  created_at: string | null;
};

export type HistoryRecommendationList = {
  items: HistoryRecommendationItem[];
  total: number;
};

export type SavedSummaryItem = {
  summary_id: number;
  summary_type: string;
  title: string;
  summary_text: string;
  country_id: number | null;
  country_name_en: string | null;
  domain_id: number | null;
  domain: string | null;
  channel_id: number | null;
  channel_name: string | null;
  period_start: string | null;
  period_end: string | null;
  source_type: string;
  source_id: number;
  tags: string[];
  importance_score: number | null;
  confidence_score: number | null;
  data_quality_status: string | null;
  rag_ready: boolean;
  embedding_status: string;
  created_at: string | null;
  updated_at: string | null;
};

export type SavedSummaryList = {
  items: SavedSummaryItem[];
  total: number;
};

const apiBaseUrl = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8000/api';

export async function fetchHealth(): Promise<HealthStatus> {
  const response = await fetch(`${apiBaseUrl}/health`);

  if (!response.ok) {
    throw new Error(`Health request failed: ${response.status}`);
  }

  return response.json();
}

export async function uploadDataFile(file: File, options: UploadOptions): Promise<UploadRunResult> {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('source_name', options.sourceName);
  formData.append('is_synthetic', String(options.isSynthetic));
  formData.append('granularity', options.granularity);

  if (options.periodStart !== '') {
    formData.append('period_start', options.periodStart);
  }

  if (options.periodEnd !== '') {
    formData.append('period_end', options.periodEnd);
  }

  const response = await fetch(`${apiBaseUrl}/data/upload`, {
    body: formData,
    method: 'POST',
  });

  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`Upload failed: ${response.status} ${errorBody}`);
  }

  return response.json();
}

export async function getUploadRuns(): Promise<UploadRunSummary[]> {
  const response = await fetch(`${apiBaseUrl}/data/uploads`);

  if (!response.ok) {
    throw new Error(`Upload history request failed: ${response.status}`);
  }

  return response.json();
}

export async function getUploadRun(runId: number): Promise<UploadRunDetail> {
  const response = await fetch(`${apiBaseUrl}/data/uploads/${runId}`);

  if (!response.ok) {
    throw new Error(`Upload run request failed: ${response.status}`);
  }

  return response.json();
}

export async function getQualityChecks(runId: number): Promise<QualityResult> {
  const response = await fetch(`${apiBaseUrl}/data/uploads/${runId}/quality-checks`);

  if (!response.ok) {
    throw new Error(`Quality checks request failed: ${response.status}`);
  }

  return response.json();
}

export async function runQualityChecks(runId: number): Promise<QualityResult> {
  const response = await fetch(`${apiBaseUrl}/data/uploads/${runId}/quality-checks/run`, {
    method: 'POST',
  });

  if (!response.ok) {
    throw new Error(`Quality checks run failed: ${response.status}`);
  }

  return response.json();
}

export async function getQualitySummary(): Promise<QualityRunSummary[]> {
  const response = await fetch(`${apiBaseUrl}/data/quality-summary`);

  if (!response.ok) {
    throw new Error(`Quality summary request failed: ${response.status}`);
  }

  return response.json();
}

export async function getCountries(search = ''): Promise<CountryList> {
  const params = new URLSearchParams({ has_data: 'true', limit: '200' });
  if (search !== '') {
    params.set('search', search);
  }

  const response = await fetch(`${apiBaseUrl}/countries?${params.toString()}`);

  if (!response.ok) {
    throw new Error(`Countries request failed: ${response.status}`);
  }

  return response.json();
}

export async function getCountryPeriod(countryId: number): Promise<CountryPeriod> {
  const response = await fetch(`${apiBaseUrl}/countries/${countryId}/available-period`);

  if (!response.ok) {
    throw new Error(`Country period request failed: ${response.status}`);
  }

  return response.json();
}

export async function getCountrySummary(
  countryId: number,
  dateFrom: string,
  dateTo: string,
  limitCompetitors = 10,
): Promise<CountrySummary> {
  const params = new URLSearchParams({
    date_from: dateFrom,
    date_to: dateTo,
    limit_competitors: String(limitCompetitors),
  });

  const response = await fetch(`${apiBaseUrl}/countries/${countryId}/summary?${params.toString()}`);

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Country summary request failed: ${response.status} ${errorText}`);
  }

  return response.json();
}

export async function getCountryMetrics(
  countryId: number,
  dateFrom: string,
  dateTo: string,
): Promise<CountryMetricsResponse> {
  const params = new URLSearchParams({
    date_from: dateFrom,
    date_to: dateTo,
    calculation_version: 'v1',
    recalculate_if_missing: 'true',
  });

  const response = await fetch(`${apiBaseUrl}/countries/${countryId}/metrics?${params.toString()}`);

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Country metrics request failed: ${response.status} ${errorText}`);
  }

  return response.json();
}

export async function getCountryDailyMetrics(
  countryId: number,
  dateFrom: string,
  dateTo: string,
): Promise<DailyMetricsResponse> {
  const params = new URLSearchParams({
    date_from: dateFrom,
    date_to: dateTo,
  });

  const response = await fetch(`${apiBaseUrl}/countries/${countryId}/metrics/daily?${params.toString()}`);

  if (!response.ok) {
    throw new Error(`Country daily metrics request failed: ${response.status}`);
  }

  return response.json();
}

export async function createCountryReport(request: CountryReportRequest): Promise<ReportResponse> {
  const response = await fetch(`${apiBaseUrl}/reports/country`, {
    body: JSON.stringify(request),
    headers: {
      'Content-Type': 'application/json',
    },
    method: 'POST',
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Country report request failed: ${response.status} ${errorText}`);
  }

  return response.json();
}

export async function getReport(reportId: number): Promise<ReportResponse> {
  const response = await fetch(`${apiBaseUrl}/reports/${reportId}`);

  if (!response.ok) {
    throw new Error(`Report request failed: ${response.status}`);
  }

  return response.json();
}

export async function getReports(): Promise<ReportList> {
  const response = await fetch(`${apiBaseUrl}/reports?report_type=country_report&limit=50`);

  if (!response.ok) {
    throw new Error(`Reports request failed: ${response.status}`);
  }

  return response.json();
}

export async function getCompetitors(search = ''): Promise<CompetitorList> {
  const params = new URLSearchParams({ has_data: 'true', limit: '200' });
  if (search !== '') {
    params.set('search', search);
  }

  const response = await fetch(`${apiBaseUrl}/competitors?${params.toString()}`);

  if (!response.ok) {
    throw new Error(`Competitors request failed: ${response.status}`);
  }

  return response.json();
}

export async function getCompetitorPeriod(domainId: number): Promise<CompetitorPeriod> {
  const response = await fetch(`${apiBaseUrl}/competitors/${domainId}/available-period`);

  if (!response.ok) {
    throw new Error(`Competitor period request failed: ${response.status}`);
  }

  return response.json();
}

export async function getCompetitorSummary(
  domainId: number,
  dateFrom: string,
  dateTo: string,
  limitCountries = 10,
): Promise<CompetitorSummary> {
  const params = new URLSearchParams({
    date_from: dateFrom,
    date_to: dateTo,
    limit_countries: String(limitCountries),
  });

  const response = await fetch(`${apiBaseUrl}/competitors/${domainId}/summary?${params.toString()}`);

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Competitor summary request failed: ${response.status} ${errorText}`);
  }

  return response.json();
}

export async function getChannelSummary(
  dateFrom: string,
  dateTo: string,
  countryId: number | null,
  domainId: number | null,
): Promise<ChannelSummary> {
  const params = new URLSearchParams({
    date_from: dateFrom,
    date_to: dateTo,
    calculation_version: 'v1',
    recalculate_if_missing: 'true',
  });
  if (countryId != null) {
    params.set('country_id', String(countryId));
  }
  if (domainId != null) {
    params.set('domain_id', String(domainId));
  }

  const response = await fetch(`${apiBaseUrl}/channels/summary?${params.toString()}`);

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Channel summary request failed: ${response.status} ${errorText}`);
  }

  return response.json();
}

export async function getChannelTrend(
  dateFrom: string,
  dateTo: string,
  countryId: number | null,
  domainId: number | null,
): Promise<ChannelTrendResponse> {
  const params = new URLSearchParams({
    date_from: dateFrom,
    date_to: dateTo,
  });
  if (countryId != null) {
    params.set('country_id', String(countryId));
  }
  if (domainId != null) {
    params.set('domain_id', String(domainId));
  }

  const response = await fetch(`${apiBaseUrl}/channels/trend?${params.toString()}`);

  if (!response.ok) {
    throw new Error(`Channel trend request failed: ${response.status}`);
  }

  return response.json();
}

export async function getJourneySources(
  dateFrom: string,
  dateTo: string,
  countryId: number | null,
  domainId: number | null,
): Promise<JourneySourcesResponse> {
  const params = new URLSearchParams({
    date_from: dateFrom,
    date_to: dateTo,
    limit: '30',
  });
  if (countryId != null) {
    params.set('country_id', String(countryId));
  }
  if (domainId != null) {
    params.set('domain_id', String(domainId));
  }

  const response = await fetch(`${apiBaseUrl}/channels/journey-sources?${params.toString()}`);

  if (!response.ok) {
    throw new Error(`Journey sources request failed: ${response.status}`);
  }

  return response.json();
}

export async function getOpportunityScore(
  countryId: number,
  dateFrom: string,
  dateTo: string,
): Promise<OpportunityScore> {
  const params = new URLSearchParams({
    date_from: dateFrom,
    date_to: dateTo,
    calculation_version: 'v1',
    calculate_if_missing: 'true',
    force_recalculate: 'false',
  });

  const response = await fetch(`${apiBaseUrl}/countries/${countryId}/opportunity-score?${params.toString()}`);

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Opportunity score request failed: ${response.status} ${errorText}`);
  }

  return response.json();
}

export async function getOpportunityCountries(
  dateFrom: string,
  dateTo: string,
  priority = '',
): Promise<OpportunityCountryList> {
  const params = new URLSearchParams({
    date_from: dateFrom,
    date_to: dateTo,
    limit: '50',
    calculate_if_missing: 'true',
    force_recalculate: 'false',
  });
  if (priority !== '') {
    params.set('priority', priority);
  }

  const response = await fetch(`${apiBaseUrl}/opportunities/countries?${params.toString()}`);

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Opportunity countries request failed: ${response.status} ${errorText}`);
  }

  return response.json();
}

export async function createBudgetStrategy(request: BudgetStrategyRequest): Promise<BudgetStrategyResponse> {
  const response = await fetch(`${apiBaseUrl}/strategy/budget`, {
    body: JSON.stringify(request),
    headers: {
      'Content-Type': 'application/json',
    },
    method: 'POST',
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Budget strategy request failed: ${response.status} ${errorText}`);
  }

  return response.json();
}

export async function getBudgetStrategies(): Promise<BudgetStrategyList> {
  const response = await fetch(`${apiBaseUrl}/strategy/budget?limit=25`);

  if (!response.ok) {
    throw new Error(`Budget strategy history request failed: ${response.status}`);
  }

  return response.json();
}

export async function getBudgetStrategy(strategyId: number): Promise<BudgetStrategyResponse> {
  const response = await fetch(`${apiBaseUrl}/strategy/budget/${strategyId}`);

  if (!response.ok) {
    throw new Error(`Budget strategy request failed: ${response.status}`);
  }

  return response.json();
}

export async function analyzeMAS(request: MASAnalyzeRequest): Promise<MASRunResponse> {
  const response = await fetch(`${apiBaseUrl}/mas/analyze`, {
    body: JSON.stringify(request),
    headers: {
      'Content-Type': 'application/json',
    },
    method: 'POST',
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`MAS analysis request failed: ${response.status} ${errorText}`);
  }

  return response.json();
}

export async function getMASRuns(): Promise<MASRunList> {
  const response = await fetch(`${apiBaseUrl}/mas/runs?limit=25`);

  if (!response.ok) {
    throw new Error(`MAS runs request failed: ${response.status}`);
  }

  return response.json();
}

export async function getMASRun(runId: number): Promise<MASRunResponse> {
  const response = await fetch(`${apiBaseUrl}/mas/runs/${runId}`);

  if (!response.ok) {
    throw new Error(`MAS run request failed: ${response.status}`);
  }

  return response.json();
}

export async function getHistoryReports(): Promise<HistoryReportList> {
  const response = await fetch(`${apiBaseUrl}/history/reports?limit=50`);

  if (!response.ok) {
    throw new Error(`History reports request failed: ${response.status}`);
  }

  return response.json();
}

export async function getHistoryAgentRuns(): Promise<HistoryAgentRunList> {
  const response = await fetch(`${apiBaseUrl}/history/agent-runs?limit=50`);

  if (!response.ok) {
    throw new Error(`History agent runs request failed: ${response.status}`);
  }

  return response.json();
}

export async function getHistoryInsights(): Promise<HistoryInsightList> {
  const response = await fetch(`${apiBaseUrl}/history/insights?limit=50`);

  if (!response.ok) {
    throw new Error(`History insights request failed: ${response.status}`);
  }

  return response.json();
}

export async function getHistoryRecommendations(): Promise<HistoryRecommendationList> {
  const response = await fetch(`${apiBaseUrl}/history/recommendations?limit=50`);

  if (!response.ok) {
    throw new Error(`History recommendations request failed: ${response.status}`);
  }

  return response.json();
}

export async function getSavedSummaries(): Promise<SavedSummaryList> {
  const response = await fetch(`${apiBaseUrl}/history/summaries?limit=50`);

  if (!response.ok) {
    throw new Error(`Saved summaries request failed: ${response.status}`);
  }

  return response.json();
}

export async function updateSavedSummary(summaryId: number, payload: Partial<SavedSummaryItem>): Promise<SavedSummaryItem> {
  const response = await fetch(`${apiBaseUrl}/history/summaries/${summaryId}`, {
    body: JSON.stringify(payload),
    headers: {
      'Content-Type': 'application/json',
    },
    method: 'PATCH',
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Saved summary update failed: ${response.status} ${errorText}`);
  }

  return response.json();
}
