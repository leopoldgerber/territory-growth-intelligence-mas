import { lazy, Suspense, useCallback, useEffect, useState } from 'react';

import { fetchHealth, type HealthStatus } from '../api/client';
import { SystemStatusCard } from '../components/SystemStatusCard';

const BudgetStrategyPage = lazy(() => import('./BudgetStrategyPage').then((module) => ({ default: module.BudgetStrategyPage })));
const ChannelIntelligencePage = lazy(() => import('./ChannelIntelligencePage').then((module) => ({ default: module.ChannelIntelligencePage })));
const CompetitorOverviewPage = lazy(() => import('./CompetitorOverviewPage').then((module) => ({ default: module.CompetitorOverviewPage })));
const CountryOverviewPage = lazy(() => import('./CountryOverviewPage').then((module) => ({ default: module.CountryOverviewPage })));
const DataUploadPage = lazy(() => import('./DataUploadPage').then((module) => ({ default: module.DataUploadPage })));
const KnowledgeHistoryPage = lazy(() => import('./KnowledgeHistoryPage').then((module) => ({ default: module.KnowledgeHistoryPage })));
const OpportunitiesPage = lazy(() => import('./OpportunitiesPage').then((module) => ({ default: module.OpportunitiesPage })));
const StrategyAssistantPage = lazy(() => import('./StrategyAssistantPage').then((module) => ({ default: module.StrategyAssistantPage })));

type AppPage = 'home' | 'upload' | 'country' | 'competitors' | 'channels' | 'opportunities' | 'budget' | 'mas' | 'history';

const NAV_ITEMS: { id: AppPage; label: string }[] = [
  { id: 'home', label: 'Home' },
  { id: 'upload', label: 'Upload' },
  { id: 'country', label: 'Country Overview' },
  { id: 'competitors', label: 'Competitors' },
  { id: 'channels', label: 'Channels' },
  { id: 'opportunities', label: 'Opportunities' },
  { id: 'budget', label: 'Budget Strategy' },
  { id: 'mas', label: 'MAS Assistant' },
  { id: 'history', label: 'Knowledge History' },
];

export function HomePage() {
  const [health, setHealth] = useState<HealthStatus | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [activePage, setActivePage] = useState<AppPage>('home');

  const loadHealth = useCallback(async () => {
    setIsLoading(true);
    setError('');

    try {
      const healthData = await fetchHealth();
      setHealth(healthData);
    } catch (requestError) {
      const message = requestError instanceof Error ? requestError.message : 'Unknown healthcheck error';
      setError(message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadHealth();
  }, [loadHealth]);

  return (
    <main className="pageShell">
      <section className="introSection">
        <p className="eyebrow">Stage 13 saved insights</p>
        <h1>Territory Growth Intelligence MAS</h1>
        <p className="leadText">Upload parser reports, validate data, score markets, and orchestrate strategy agents over country signals.</p>
      </section>

      <nav className="appNavigation" aria-label="Application sections">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            className={activePage === item.id ? 'secondaryButton active' : 'secondaryButton'}
            type="button"
            onClick={() => setActivePage(item.id)}
          >
            {item.label}
          </button>
        ))}
      </nav>

      <SystemStatusCard health={health} isLoading={isLoading} error={error} onRefresh={loadHealth} />
      <Suspense fallback={<p className="mutedText">Loading section...</p>}>
        {activePage === 'home' && (
          <section className="countryOverview" aria-label="Home">
            <div className="sectionHeader">
              <div>
                <h2>Workspace</h2>
                <p>Select a section above to load only the workflow you need.</p>
              </div>
            </div>
          </section>
        )}
        {activePage === 'upload' && <DataUploadPage />}
        {activePage === 'country' && <CountryOverviewPage />}
        {activePage === 'competitors' && <CompetitorOverviewPage />}
        {activePage === 'channels' && <ChannelIntelligencePage />}
        {activePage === 'opportunities' && <OpportunitiesPage />}
        {activePage === 'budget' && <BudgetStrategyPage />}
        {activePage === 'mas' && <StrategyAssistantPage />}
        {activePage === 'history' && <KnowledgeHistoryPage />}
      </Suspense>
    </main>
  );
}
