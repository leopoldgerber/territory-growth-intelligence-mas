from fastapi import APIRouter, Depends

from app.core.config import Settings, get_settings
from app.services.health_service import build_health


router = APIRouter(prefix='/health', tags=['health'])


@router.get('')
def read_health(settings: Settings = Depends(get_settings)) -> dict[str, str]:
    """Read system health.
    Args:
        settings (Settings): Application settings."""
    health_data = build_health(settings)
    return health_data
