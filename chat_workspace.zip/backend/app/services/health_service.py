from app.core.config import Settings
from app.db.session import check_database


def build_health(settings: Settings) -> dict[str, str]:
    """Build system health.
    Args:
        settings (Settings): Application settings."""
    database_status = 'ok'
    system_status = 'ok'
    try:
        check_database()
    except Exception:
        database_status = 'error'
        system_status = 'degraded'
    health_data = {
        'status': system_status,
        'backend': 'ok',
        'database': database_status,
        'app_name': settings.app_name,
        'environment': settings.app_env,
    }
    return health_data
