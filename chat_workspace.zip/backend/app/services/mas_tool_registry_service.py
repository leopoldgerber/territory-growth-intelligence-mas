from datetime import date

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.schemas.report import CountryReportRequest
from app.schemas.strategy import BudgetStrategyRequest
from app.services.budget_strategy_service import generate_strategy
from app.services.channel_analysis_service import build_summary as build_channel_summary
from app.services.country_competitor_service import list_competitors
from app.services.country_metrics_service import get_metrics
from app.services.country_query_service import get_country
from app.services.country_report_service import create_country_report
from app.services.country_summary_service import build_country_summary
from app.services.journey_source_service import build_journey
from app.services.opportunity_scoring_service import get_score
from app.services.report_storage_service import find_report


def dump_model(value: object) -> dict[str, object]:
    """Dump model value.
    Args:
        value (object): Source value."""
    if hasattr(value, 'model_dump'):
        dumped_value = value.model_dump(mode='json')
        return dumped_value
    if isinstance(value, dict):
        return value
    return {'value': value}


def tool_names() -> list[str]:
    """List tool names.
    Args:
        None (None): No arguments."""
    names = [
        'get_country_summary',
        'get_country_metrics',
        'get_top_competitors_by_country',
        'get_channel_summary',
        'get_journey_sources',
        'get_opportunity_score',
        'generate_budget_strategy',
        'create_country_report',
    ]
    return names


def country_summary(
    session: Session,
    country_id: int,
    date_from: date,
    date_to: date,
    calculation_version: str,
) -> dict[str, object]:
    """Call country summary tool.
    Args:
        session (Session): Database session.
        country_id (int): Country identifier.
        date_from (date): Period start date.
        date_to (date): Period end date.
        calculation_version (str): Calculation version."""
    country = get_country(session, country_id)
    if country is None:
        raise HTTPException(status_code=404, detail='Country not found.')
    summary = build_country_summary(session, country, date_from, date_to, 10)
    return dump_model(summary)


def country_metrics(
    session: Session,
    country_id: int,
    date_from: date,
    date_to: date,
    calculation_version: str,
) -> dict[str, object]:
    """Call country metrics tool.
    Args:
        session (Session): Database session.
        country_id (int): Country identifier.
        date_from (date): Period start date.
        date_to (date): Period end date.
        calculation_version (str): Calculation version."""
    metrics = get_metrics(session, country_id, date_from, date_to, calculation_version, True)
    return dump_model(metrics)


def top_competitors(
    session: Session,
    country_id: int,
    date_from: date,
    date_to: date,
    calculation_version: str,
) -> dict[str, object]:
    """Call competitors tool.
    Args:
        session (Session): Database session.
        country_id (int): Country identifier.
        date_from (date): Period start date.
        date_to (date): Period end date.
        calculation_version (str): Calculation version."""
    competitors = list_competitors(session, country_id, date_from, date_to, 10, 'traffic', 'desc')
    return competitors


def channel_summary(
    session: Session,
    country_id: int,
    date_from: date,
    date_to: date,
    calculation_version: str,
) -> dict[str, object]:
    """Call channel summary tool.
    Args:
        session (Session): Database session.
        country_id (int): Country identifier.
        date_from (date): Period start date.
        date_to (date): Period end date.
        calculation_version (str): Calculation version."""
    summary = build_channel_summary(session, country_id, None, date_from, date_to, calculation_version)
    return dump_model(summary)


def journey_sources(
    session: Session,
    country_id: int,
    date_from: date,
    date_to: date,
    calculation_version: str,
) -> dict[str, object]:
    """Call journey sources tool.
    Args:
        session (Session): Database session.
        country_id (int): Country identifier.
        date_from (date): Period start date.
        date_to (date): Period end date.
        calculation_version (str): Calculation version."""
    items, warnings = build_journey(session, country_id, None, None, date_from, date_to, 10, calculation_version)
    response = {'items': [dump_model(item) for item in items], 'warnings': warnings}
    return response


def opportunity_score(
    session: Session,
    country_id: int,
    date_from: date,
    date_to: date,
    calculation_version: str,
) -> dict[str, object]:
    """Call opportunity score tool.
    Args:
        session (Session): Database session.
        country_id (int): Country identifier.
        date_from (date): Period start date.
        date_to (date): Period end date.
        calculation_version (str): Calculation version."""
    score = get_score(session, country_id, date_from, date_to, calculation_version, True, False)
    return dump_model(score)


def budget_strategy(
    session: Session,
    country_id: int,
    date_from: date,
    date_to: date,
    calculation_version: str,
    budget_amount: float,
    currency_code: str,
    campaign_goal: str,
    risk_appetite: str,
) -> dict[str, object]:
    """Call budget strategy tool.
    Args:
        session (Session): Database session.
        country_id (int): Country identifier.
        date_from (date): Period start date.
        date_to (date): Period end date.
        calculation_version (str): Calculation version.
        budget_amount (float): Budget amount.
        currency_code (str): Currency code.
        campaign_goal (str): Campaign goal.
        risk_appetite (str): Risk appetite."""
    request = BudgetStrategyRequest(
        country_id=country_id,
        date_from=date_from,
        date_to=date_to,
        budget_amount=budget_amount,
        currency_code=currency_code,
        campaign_goal=campaign_goal,
        risk_appetite=risk_appetite,
        calculation_version=calculation_version,
    )
    strategy = generate_strategy(session, request)
    return dump_model(strategy)


def country_report(
    session: Session,
    country_id: int,
    date_from: date,
    date_to: date,
    calculation_version: str,
) -> dict[str, object]:
    """Call country report tool.
    Args:
        session (Session): Database session.
        country_id (int): Country identifier.
        date_from (date): Period start date.
        date_to (date): Period end date.
        calculation_version (str): Calculation version."""
    existing_report = find_report(session, 'country_report', country_id, date_from, date_to, calculation_version)
    if existing_report is not None:
        return existing_report
    request = CountryReportRequest(
        country_id=country_id,
        date_from=date_from,
        date_to=date_to,
        limit_competitors=10,
        include_channels=True,
        include_recommendations=True,
        calculation_version=calculation_version,
    )
    report = create_country_report(session, request)
    return dump_model(report)
