from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = 'Territory Growth Intelligence MAS'
    app_env: str = 'local'
    debug: bool = True
    backend_host: str = '0.0.0.0'
    backend_port: int = 8000
    postgres_host: str = 'postgres'
    postgres_port: int = 5432
    postgres_db: str = 'tgi_db'
    postgres_user: str = 'tgi_user'
    postgres_password: str = 'tgi_password'
    frontend_url: str = 'http://localhost:5173'
    upload_storage_path: str = 'uploads'
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='ignore')

    @property
    def database_url(self) -> str:
        """Build database URL.
        Args:
            self (Settings): Application settings."""
        return (
            f'postgresql+psycopg2://{self.postgres_user}:{self.postgres_password}'
            f'@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}'
        )


@lru_cache
def get_settings() -> Settings:
    """Get cached settings.
    Args:
        None (None): No arguments are required."""
    settings = Settings()
    return settings
