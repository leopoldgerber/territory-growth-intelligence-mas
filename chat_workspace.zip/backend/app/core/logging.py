import logging


def setup_logging() -> logging.Logger:
    """Setup application logging.
    Args:
        None (None): No arguments are required."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(name)s %(message)s',
    )
    logger = logging.getLogger('territory_growth_api')
    return logger
